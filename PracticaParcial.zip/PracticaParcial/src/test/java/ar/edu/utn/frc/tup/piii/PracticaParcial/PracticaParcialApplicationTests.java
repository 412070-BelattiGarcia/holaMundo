package ar.edu.utn.frc.tup.piii.PracticaParcial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaParcialApplicationTests {

	@Test
	void contextLoads() {
	}

}
